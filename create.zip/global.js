const apiUrl = 'https://x8ki-letl-twmt.n7.xano.io/api:4VVVPdTp/projects';

function loader(show) {
    var loader = document.getElementById("loader");
    loader.style.display = show ? "flex" : 'none';
}